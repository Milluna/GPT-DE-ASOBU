import type { PlayerState } from "../types";

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function wrapAngle(value: number): number {
  const twoPi = Math.PI * 2;
  let result = value % twoPi;
  if (result > Math.PI) result -= twoPi;
  if (result < -Math.PI) result += twoPi;
  return result;
}

function damp(current: number, target: number, sharpness: number, dt: number): number {
  return current + (target - current) * (1 - Math.exp(-sharpness * dt));
}

function dampAngle(current: number, target: number, sharpness: number, dt: number): number {
  return wrapAngle(current + wrapAngle(target - current) * (1 - Math.exp(-sharpness * dt)));
}

export class RemoteInterpolator {
  private current: PlayerState;
  private target: PlayerState;
  private hasSnapshot = false;

  constructor(initial: PlayerState) {
    this.current = { ...initial };
    this.target = { ...initial };
  }

  push(state: PlayerState): void {
    this.target = { ...state };
    if (!this.hasSnapshot) {
      this.current = { ...state };
      this.hasSnapshot = true;
    }
  }

  update(dtSeconds: number): PlayerState {
    const dt = clamp(dtSeconds, 0, 0.05);
    this.current.x = damp(this.current.x, this.target.x, 17, dt);
    this.current.z = damp(this.current.z, this.target.z, 17, dt);
    this.current.yaw = dampAngle(this.current.yaw, this.target.yaw, 20, dt);
    this.current.speed = damp(this.current.speed, this.target.speed, 15, dt);
    this.current.motion = this.target.motion;
    this.current.motionSequence = this.target.motionSequence;
    this.current.clientTime = this.target.clientTime;
    return { ...this.current };
  }
}
