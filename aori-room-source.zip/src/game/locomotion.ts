import type { MotionName, PlayerState } from "../types";

export interface StickInput {
  /** -1 = left, +1 = right */
  x: number;
  /** -1 = backward/down-screen, +1 = forward/up-screen */
  y: number;
}

export interface LocomotionTuning {
  deadZone: number;
  maxSpeed: number;
  acceleration: number;
  deceleration: number;
  turnSharpness: number;
  startThreshold: number;
  startReleaseThreshold: number;
  startDuration: number;
  startRetriggerCooldownMs: number;
  sandoriAngularVelocity: number;
  sandoriHoldSeconds: number;
  boundaryX: number;
  boundaryZ: number;
}

export const DEFAULT_LOCOMOTION_TUNING: LocomotionTuning = {
  deadZone: 0.075,
  maxSpeed: 4.85,
  acceleration: 27.5,
  deceleration: 35,
  turnSharpness: 18,
  startThreshold: 0.34,
  startReleaseThreshold: 0.18,
  startDuration: 0.19,
  startRetriggerCooldownMs: 48,
  sandoriAngularVelocity: 3.7,
  sandoriHoldSeconds: 0.2,
  boundaryX: 4.35,
  boundaryZ: 4.85,
};

const EPSILON = 1e-6;
const TWO_PI = Math.PI * 2;

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function wrapAngle(value: number): number {
  let result = value % TWO_PI;
  if (result > Math.PI) result -= TWO_PI;
  if (result < -Math.PI) result += TWO_PI;
  return result;
}

function angleDelta(target: number, current: number): number {
  return wrapAngle(target - current);
}

function dampAngle(current: number, target: number, sharpness: number, dt: number): number {
  const t = 1 - Math.exp(-sharpness * dt);
  return wrapAngle(current + angleDelta(target, current) * t);
}

function moveToward2D(
  currentX: number,
  currentZ: number,
  targetX: number,
  targetZ: number,
  maxDistance: number,
): [number, number] {
  const dx = targetX - currentX;
  const dz = targetZ - currentZ;
  const distance = Math.hypot(dx, dz);
  if (distance <= maxDistance || distance < EPSILON) return [targetX, targetZ];
  const scale = maxDistance / distance;
  return [currentX + dx * scale, currentZ + dz * scale];
}

function responseCurve(value: number): number {
  // Lightly aggressive around the middle, but still leaves precise slow movement near the center.
  const smooth = value * value * (3 - 2 * value);
  return Math.pow(smooth, 0.78);
}

export class LocomotionController {
  readonly tuning: LocomotionTuning;

  x = 0;
  z = 1.65;
  velocityX = 0;
  velocityZ = 0;
  yaw = Math.PI;
  speed = 0;
  motion: MotionName = "idle";
  motionSequence = 0;

  private startTimer = 0;
  private sandoriTimer = 0;
  private activeStartSide: -1 | 0 | 1 = 0;
  private latchedInputSide: -1 | 0 | 1 = 0;
  private lastStartAtMs = -Infinity;
  private lastInputAngle: number | null = null;
  private angularVelocity = 0;
  private wasSandori = false;

  constructor(tuning: Partial<LocomotionTuning> = {}) {
    this.tuning = { ...DEFAULT_LOCOMOTION_TUNING, ...tuning };
  }

  reset(x = 0, z = 1.65, yaw = Math.PI): void {
    this.x = x;
    this.z = z;
    this.velocityX = 0;
    this.velocityZ = 0;
    this.yaw = yaw;
    this.speed = 0;
    this.motion = "idle";
    this.motionSequence = 0;
    this.startTimer = 0;
    this.sandoriTimer = 0;
    this.activeStartSide = 0;
    this.latchedInputSide = 0;
    this.lastStartAtMs = -Infinity;
    this.lastInputAngle = null;
    this.angularVelocity = 0;
    this.wasSandori = false;
  }

  update(dtSeconds: number, input: StickInput, nowMs: number): PlayerState {
    const dt = clamp(Number.isFinite(dtSeconds) ? dtSeconds : 0, 0, 0.05);
    const inputX = clamp(Number.isFinite(input.x) ? input.x : 0, -1, 1);
    const inputY = clamp(Number.isFinite(input.y) ? input.y : 0, -1, 1);
    const rawMagnitude = Math.min(1, Math.hypot(inputX, inputY));
    const normalizedMagnitude = clamp(
      (rawMagnitude - this.tuning.deadZone) / (1 - this.tuning.deadZone),
      0,
      1,
    );
    const hasInput = normalizedMagnitude > 0;

    let directionX = 0;
    let directionZ = 0;
    if (rawMagnitude > EPSILON) {
      directionX = inputX / rawMagnitude;
      directionZ = -inputY / rawMagnitude;
    }

    const desiredSpeed = this.tuning.maxSpeed * responseCurve(normalizedMagnitude);
    const targetVelocityX = directionX * desiredSpeed;
    const targetVelocityZ = directionZ * desiredSpeed;
    const rate = hasInput ? this.tuning.acceleration : this.tuning.deceleration;
    [this.velocityX, this.velocityZ] = moveToward2D(
      this.velocityX,
      this.velocityZ,
      targetVelocityX,
      targetVelocityZ,
      rate * dt,
    );

    this.speed = Math.hypot(this.velocityX, this.velocityZ);
    if (this.speed > 0.045) {
      const desiredYaw = Math.atan2(this.velocityX, this.velocityZ);
      this.yaw = dampAngle(this.yaw, desiredYaw, this.tuning.turnSharpness, dt);
    }

    this.x += this.velocityX * dt;
    this.z += this.velocityZ * dt;

    if (this.x < -this.tuning.boundaryX || this.x > this.tuning.boundaryX) {
      this.x = clamp(this.x, -this.tuning.boundaryX, this.tuning.boundaryX);
      this.velocityX = 0;
    }
    if (this.z < -this.tuning.boundaryZ || this.z > this.tuning.boundaryZ) {
      this.z = clamp(this.z, -this.tuning.boundaryZ, this.tuning.boundaryZ);
      this.velocityZ = 0;
    }

    this.updateInputAngularVelocity(dt, inputX, inputY, rawMagnitude);
    this.updateStartTrigger(inputX, rawMagnitude, nowMs);

    this.startTimer = Math.max(0, this.startTimer - dt);
    this.sandoriTimer = Math.max(0, this.sandoriTimer - dt);

    const isCircularInput =
      normalizedMagnitude > 0.5 &&
      this.speed > 1.15 &&
      Math.abs(this.angularVelocity) >= this.tuning.sandoriAngularVelocity;

    if (isCircularInput) {
      this.sandoriTimer = this.tuning.sandoriHoldSeconds;
    }

    const isSandori = this.startTimer <= 0 && this.sandoriTimer > 0;
    if (isSandori && !this.wasSandori) {
      this.motionSequence += 1;
    }
    this.wasSandori = isSandori;

    if (this.startTimer > 0 && this.activeStartSide !== 0) {
      this.motion = this.activeStartSide < 0 ? "start-left" : "start-right";
    } else if (isSandori) {
      this.motion = "sandori";
    } else if (this.speed > 0.08) {
      this.motion = "run";
    } else {
      this.motion = "idle";
    }

    return this.snapshot(nowMs);
  }

  snapshot(clientTime = performance.now()): PlayerState {
    return {
      x: this.x,
      z: this.z,
      yaw: this.yaw,
      speed: this.speed,
      motion: this.motion,
      motionSequence: this.motionSequence,
      clientTime,
    };
  }

  private updateInputAngularVelocity(
    dt: number,
    inputX: number,
    inputY: number,
    rawMagnitude: number,
  ): void {
    if (rawMagnitude < 0.28 || dt <= 0) {
      this.lastInputAngle = null;
      this.angularVelocity *= Math.exp(-10 * dt);
      return;
    }

    const angle = Math.atan2(inputY, inputX);
    if (this.lastInputAngle !== null) {
      const instantaneous = angleDelta(angle, this.lastInputAngle) / dt;
      const blend = 1 - Math.exp(-12 * dt);
      this.angularVelocity += (instantaneous - this.angularVelocity) * blend;
    }
    this.lastInputAngle = angle;
  }

  private updateStartTrigger(inputX: number, rawMagnitude: number, nowMs: number): void {
    let side: -1 | 0 | 1 = 0;
    if (rawMagnitude > 0.3 && Math.abs(inputX) >= this.tuning.startThreshold) {
      side = inputX < 0 ? -1 : 1;
    }

    if (Math.abs(inputX) <= this.tuning.startReleaseThreshold || rawMagnitude <= 0.22) {
      this.latchedInputSide = 0;
    }

    const changedSide = side !== 0 && side !== this.latchedInputSide;
    const cooldownElapsed = nowMs - this.lastStartAtMs >= this.tuning.startRetriggerCooldownMs;
    if (changedSide && cooldownElapsed) {
      this.latchedInputSide = side;
      this.activeStartSide = side;
      this.startTimer = this.tuning.startDuration;
      this.lastStartAtMs = nowMs;
      this.motionSequence += 1;
    }
    // When the player flips sides inside the tiny cooldown window, keep the old latch.
    // The held opposite direction will then retrigger on the first eligible frame instead
    // of being swallowed. This is what makes rapid left/right taunt inputs repeat reliably.
  }
}
